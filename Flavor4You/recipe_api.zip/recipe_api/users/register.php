<?php
header('Content-Type: application/json');
include '../koneksi.php';

$username = $_POST['username'] ?? '';
$email    = $_POST['email']    ?? '';
$password = $_POST['password'] ?? '';

if ($username === '' || $email === '' || $password === '') {
    echo json_encode([
        "success" => false,
        "message" => "Data tidak lengkap"
    ]);
    exit;
}

// bersihin basic
$username = $conn->real_escape_string($username);
$email    = $conn->real_escape_string($email);

// cek sudah dipakai atau belum
$sql  = "SELECT id FROM users WHERE username='$username' OR email='$email' LIMIT 1";
$res  = $conn->query($sql);

if ($res && $res->num_rows > 0) {
    echo json_encode([
        "success" => false,
        "message" => "Username atau email sudah dipakai"
    ]);
    exit;
}

// hash password
$hash = password_hash($password, PASSWORD_BCRYPT);

// insert user baru
$sqlInsert = "
    INSERT INTO users (username, email, password)
    VALUES ('$username', '$email', '$hash')
";

if ($conn->query($sqlInsert) === TRUE) {
    echo json_encode([
        "success" => true,
        "message" => "Registrasi berhasil",
        "user_id" => $conn->insert_id
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Error: " . $conn->error
    ]);
}
?>
