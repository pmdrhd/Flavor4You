<?php
header('Content-Type: application/json');
include '../koneksi.php';

// boleh pakai email atau username untuk login
$identifier = $_POST['identifier'] ?? '';  // email atau username
$password   = $_POST['password']   ?? '';

if ($identifier === '' || $password === '') {
    echo json_encode([
        "success" => false,
        "message" => "Data tidak lengkap"
    ]);
    exit;
}

$identifier = $conn->real_escape_string($identifier);

$sql = "
    SELECT id, username, email, password
    FROM users
    WHERE email='$identifier' OR username='$identifier'
    LIMIT 1
";
$res = $conn->query($sql);

if (!$res || $res->num_rows === 0) {
    echo json_encode([
        "success" => false,
        "message" => "User tidak ditemukan"
    ]);
    exit;
}

$user = $res->fetch_assoc();

if (!password_verify($password, $user['password'])) {
    echo json_encode([
        "success" => false,
        "message" => "Password salah"
    ]);
    exit;
}

// sukses login
echo json_encode([
    "success" => true,
    "message" => "Login berhasil",
    "data" => [
        "id"       => (int)$user['id'],
        "username" => $user['username'],
        "email"    => $user['email']
    ]
]);
?>
