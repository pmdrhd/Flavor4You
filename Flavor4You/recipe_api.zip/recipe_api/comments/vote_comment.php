<?php
header('Content-Type: application/json');
include '../koneksi.php';

$comment_id    = isset($_POST['comment_id']) ? intval($_POST['comment_id']) : 0;
$delta_like    = isset($_POST['delta_like']) ? intval($_POST['delta_like']) : 0;
$delta_dislike = isset($_POST['delta_dislike']) ? intval($_POST['delta_dislike']) : 0;

if ($comment_id <= 0) {
    echo json_encode([
        "success" => false,
        "message" => "comment_id invalid"
    ]);
    exit;
}

$sql = "UPDATE comments
        SET like_count    = GREATEST(like_count + $delta_like, 0),
            dislike_count = GREATEST(dislike_count + $delta_dislike, 0)
        WHERE id = $comment_id";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode(["success" => false, "message" => $conn->error]);
}
?>
