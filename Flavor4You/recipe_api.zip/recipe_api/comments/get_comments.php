<?php
header('Content-Type: application/json');
include '../koneksi.php';

$recipe_id = isset($_GET['recipe_id']) ? intval($_GET['recipe_id']) : 0;

if ($recipe_id <= 0) {
    echo json_encode([
        "success" => false,
        "message" => "recipe_id invalid"
    ]);
    exit;
}

$sql = "SELECT id, recipe_id, parent_id, user_name, rating, comment_text,
               created_at, like_count, dislike_count
        FROM comments
        WHERE recipe_id = $recipe_id
        ORDER BY created_at ASC";

$res = $conn->query($sql);
$data = [];

if ($res) {
    while ($row = $res->fetch_assoc()) {
        $data[] = $row;
    }
}

echo json_encode([
    "success" => true,
    "data"    => $data
]);
?>
