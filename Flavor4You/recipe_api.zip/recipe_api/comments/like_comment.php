<?php
header('Content-Type: application/json');
include '../koneksi.php';

$comment_id = intval($_POST['comment_id']);
$delta      = isset($_POST['delta']) ? intval($_POST['delta']) : 1; // +1 atau -1

// Pastikan tidak minus
$sql = "UPDATE comments 
        SET like_count = GREATEST(like_count + $delta, 0)
        WHERE id = $comment_id";

if ($conn->query($sql) === TRUE) {
    echo json_encode(array("success" => true));
} else {
    echo json_encode(array("success" => false, "message" => $conn->error));
}
?>
