<?php
header('Content-Type: application/json');
include '../koneksi.php';

$user_id      = $_POST['user_id'] ?? '';
$recipe_id    = $_POST['recipe_id'] ?? '';
$user_name    = $_POST['user_name'] ?? '';
$rating       = $_POST['rating'] ?? 0;
$comment_text = $_POST['comment_text'] ?? '';
$parent_id    = $_POST['parent_id'] ?? '0';   // "0" = comment utama

// Validasi sederhana
if ($user_id === '' || $recipe_id === '' || $user_name === '' || $comment_text === '') {
    echo json_encode([
        "success" => false,
        "message" => "Data tidak lengkap"
    ]);
    exit;
}

$recipe_id = intval($recipe_id);
$user_id   = intval($user_id);
$rating    = floatval($rating);
$parent_id = ($parent_id === '' || $parent_id === '0') ? 0 : intval($parent_id);

// Sanitasi teks
$user_name    = $conn->real_escape_string($user_name);
$comment_text = $conn->real_escape_string($comment_text);

// Query sekarang pakai user_id
$sql = "INSERT INTO comments (recipe_id, parent_id, user_id, user_name, rating, comment_text, created_at, like_count, dislike_count)
        VALUES ($recipe_id, $parent_id, $user_id, '$user_name', $rating, '$comment_text', NOW(), 0, 0)";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["success" => true, "message" => "Comment added"]);
} else {
    echo json_encode(["success" => false, "message" => $conn->error]);
}
?>
