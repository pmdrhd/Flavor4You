<?php
header("Content-Type: application/json");
require "../koneksi.php";

$sql = "SELECT kategori FROM recipes";
$q   = $conn->query($sql);

$allCategories = [];

while ($row = $q->fetch_assoc()) {

    $json = json_decode($row['kategori'], true);

    if (is_array($json)) {
        foreach ($json as $cat) {
            $allCategories[] = $cat;
        }
    }
}

// Hilangkan kategori duplikat
$unique = array_unique($allCategories);

// Sort ascending
sort($unique);

// Format kapital + spasi
$formatted = [];
foreach ($unique as $cat) {
    $pretty = ucwords(str_replace("_", " ", $cat));
    $formatted[] = [
        "key"  => $cat,     // original (untuk filter API)
        "name" => $pretty,  // tampil cantik
    ];
}

echo json_encode([
    "success" => true,
    "data"    => $formatted
]);
