<?php
header('Content-Type: application/json');
include '../koneksi.php';

$IMAGE_BASE_URL = "http://10.0.2.2/recipe_api/uploads/";
$sort       = $_GET['sort'] ?? "az";

switch ($sort) {
    case "newest":   $order = "ORDER BY r.id DESC"; break;
    case "oldest":   $order = "ORDER BY r.id ASC"; break;
    default:         $order = "ORDER BY r.nama_resep ASC"; break;
}

$sql = "
    SELECT 
        r.id,
        r.nama_resep,
        r.gambar,
        r.bahan,
        r.instruksi,
        r.porsi,
        r.durasi,
        r.kategori,
        r.posted_by,
        r.created_at,
        u.username AS posted_name,
        COALESCE((SELECT AVG(c.rating) FROM comments c WHERE c.recipe_id = r.id), 0) AS avg_rating,
        COALESCE((SELECT COUNT(*) FROM comments c WHERE c.recipe_id = r.id), 0) AS total_comments
    FROM recipes r
    LEFT JOIN users u ON r.posted_by = u.id
    $order
";

$res = $conn->query($sql);

$data = [];
if ($res) {
    while ($row = $res->fetch_assoc()) {
        $row['id']             = (int)$row['id'];
        $row['posted_by']      = (int)$row['posted_by'];
        $row['avg_rating']     = (float)$row['avg_rating'];
        $row['total_comments'] = (int)$row['total_comments'];

        $row['image_url'] = $IMAGE_BASE_URL . $row['gambar'];

        // decode kategori JSON
        $row['kategori'] = $row['kategori'] ? json_decode($row['kategori'], true) : [];

        $data[] = $row;
    }
}

echo json_encode([
    "success" => true,
    "data"    => $data
]);
?>
