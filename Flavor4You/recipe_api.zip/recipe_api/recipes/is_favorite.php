<?php
header('Content-Type: application/json');
include '../koneksi.php';
$user_id = intval($_GET['user_id'] ?? 0);
$recipe_id = intval($_GET['recipe_id'] ?? 0);
if ($user_id && $recipe_id) {
    $res = $conn->query("SELECT COUNT(*) as total FROM favorites WHERE user_id=$user_id AND recipe_id=$recipe_id");
    $row = $res->fetch_assoc();
    echo json_encode([
        "success" => true,
        "favorite" => $row['total'] > 0
    ]);
} else {
    echo json_encode(["success"=>false,"favorite"=>false]);
}
?>
