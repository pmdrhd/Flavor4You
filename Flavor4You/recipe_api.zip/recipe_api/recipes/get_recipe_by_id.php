<?php
header('Content-Type: application/json');
include '../koneksi.php';

$IMAGE_BASE_URL = "http://localhost/recipe_api/uploads/";

if (!isset($_GET['id'])) {
    echo json_encode([
        "success" => false,
        "message" => "Missing recipe ID"
    ]);
    exit;
}

$recipeId = intval($_GET['id']);

$sql = "
    SELECT 
        r.id,
        r.nama_resep,
        r.gambar,
        r.bahan,
        r.instruksi,
        r.porsi,
        r.durasi,
        r.kategori,
        r.posted_by,
        r.created_at,
        u.username AS posted_name,
        COALESCE((SELECT AVG(c.rating) FROM comments c WHERE c.recipe_id = r.id), 0) AS avg_rating,
        COALESCE((SELECT COUNT(*) FROM comments c WHERE c.recipe_id = r.id), 0) AS total_comments
    FROM recipes r
    LEFT JOIN users u ON r.posted_by = u.id
    WHERE r.id = $recipeId
    LIMIT 1
";

$res = $conn->query($sql);

if (!$res || $res->num_rows == 0) {
    echo json_encode([
        "success" => false,
        "message" => "Recipe not found"
    ]);
    exit;
}

$row = $res->fetch_assoc();

$row['id']             = (int)$row['id'];
$row['posted_by']      = (int)$row['posted_by'];
$row['avg_rating']     = (float)$row['avg_rating'];
$row['total_comments'] = (int)$row['total_comments'];
$row['image_url']      = $IMAGE_BASE_URL . $row['gambar'];

// convert kategori JSON string → array
$row['kategori'] = $row['kategori'] ? json_decode($row['kategori'], true) : [];

echo json_encode([
    "success" => true,
    "data" => $row
]);
?>
