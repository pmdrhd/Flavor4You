<?php
ob_clean(); // hapus output sebelumnya
header("Content-Type: application/json; charset=UTF-8");
include "../koneksi.php";

$search      = $_GET['search'] ?? "";
$categories  = isset($_GET['kategori']) && $_GET['kategori'] !== "" ? explode(",", $_GET['kategori']) : [];
$favoriteRaw = $_GET['favorite_ids'] ?? "";
$sort        = $_GET['sort'] ?? "az";

// Favorite
$favoriteIds = [];
if ($favoriteRaw !== "") {
    foreach (explode(",", $favoriteRaw) as $id) {
        if (is_numeric($id)) $favoriteIds[] = intval($id);
    }
}

$sql = "SELECT * FROM recipes WHERE 1=1";

// SEARCH
if ($search !== "") {
    $sql .= " AND nama_resep LIKE ?";
}

// FAVORITE
if (!empty($favoriteIds)) {
    $placeholder = implode(",", array_fill(0, count($favoriteIds), "?"));
    $sql .= " AND id IN ($placeholder)";
}

// CATEGORIES (gunakan placeholder numerik agar aman)
foreach ($categories as $c) {
    $sql .= " AND JSON_CONTAINS(kategori, ?)";
}

// SORT
switch ($sort) {
    case "newest":  $sql .= " ORDER BY created_at DESC"; break;
    case "oldest":  $sql .= " ORDER BY created_at ASC";  break;
    default:        $sql .= " ORDER BY nama_resep ASC";  break;
}

$stmt = $conn->prepare($sql);

// BIND PARAMETER
$bindIdx = 1;

// search
if ($search !== "") {
    $stmt->bindValue($bindIdx++, "%$search%", PDO::PARAM_STR);
}

// favorite
foreach ($favoriteIds as $id) {
    $stmt->bindValue($bindIdx++, $id, PDO::PARAM_INT);
}

// kategori JSON
foreach ($categories as $cat) {
    $stmt->bindValue($bindIdx++, json_encode($cat), PDO::PARAM_STR);
}

$stmt->execute();
$data = $stmt->fetchAll(PDO::FETCH_ASSOC);

// format kategori
foreach ($data as &$row) {
    $row["kategori"] = json_decode($row["kategori"], true) ?? [];
}

echo json_encode([
    "success" => true,
    "data" => $data
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
