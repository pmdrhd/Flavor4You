<?php
header('Content-Type: application/json');
include '../koneksi.php';

$nama_resep = $_POST['nama_resep'] ?? '';
$gambar     = $_POST['gambar']     ?? '';  // boleh kosong dulu
$bahan      = $_POST['bahan']      ?? '';
$instruksi  = $_POST['instruksi']  ?? '';
$posted_by  = $_POST['posted_by']  ?? '';

if ($nama_resep === '' || $bahan === '' || $instruksi === '' || $posted_by === '') {
    echo json_encode([
        "success" => false,
        "message" => "Data tidak lengkap"
    ]);
    exit;
}

$nama_resep = $conn->real_escape_string($nama_resep);
$gambar     = $conn->real_escape_string($gambar);
$bahan      = $conn->real_escape_string($bahan);
$instruksi  = $conn->real_escape_string($instruksi);
$posted_by  = (int)$posted_by;

$sql = "
    INSERT INTO recipes (nama_resep, gambar, bahan, instruksi, posted_by)
    VALUES ('$nama_resep', '$gambar', '$bahan', '$instruksi', $posted_by)
";

if ($conn->query($sql) === TRUE) {
    echo json_encode([
        "success" => true,
        "message" => "Resep berhasil ditambahkan",
        "recipe_id" => $conn->insert_id
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Error: " . $conn->error
    ]);
}
?>
