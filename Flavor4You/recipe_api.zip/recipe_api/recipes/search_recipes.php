<?php
header("Content-Type: application/json");
require "../koneksi.php";

$search     = $_GET['search'] ?? "";
$kategori   = $_GET['kategori'] ?? "";
$sort       = $_GET['sort'] ?? "az";
$user_id    = $_GET['user_id'] ?? 0;

$where = [];
if ($search !== "") {
    $s = $conn->real_escape_string($search);
    $where[] = "r.nama_resep LIKE '%$s%'";
}

if ($kategori !== "") {
    $kat = explode(",", $kategori);
    $escaped = array_map(fn($x) => "'" . $conn->real_escape_string($x) . "'", $kat);
    $where[] = "r.kategori IN (" . implode(",", $escaped) . ")";
}

$filter = count($where) ? "WHERE " . implode(" AND ", $where) : "";

switch ($sort) {
    case "newest":   $order = "ORDER BY r.id DESC"; break;
    case "oldest":   $order = "ORDER BY r.id ASC"; break;
    default:         $order = "ORDER BY r.nama_resep ASC"; break;
}

$sql = "
SELECT 
    r.*,
    IF(f.id IS NULL, 0, 1) AS favorite,
    COALESCE(ROUND(AVG(c.rating), 1), 0) AS avg_rating,
    COUNT(c.id) AS total_comments
FROM recipes r
LEFT JOIN favorites f 
    ON f.recipe_id = r.id AND f.user_id = $user_id
LEFT JOIN comments c 
    ON c.recipe_id = r.id
GROUP BY r.id
$order
";

$q = $conn->query($sql);
$data = [];

while ($row = $q->fetch_assoc()) {

    $kategoriArr = json_decode($row['kategori'], true);

    // jika ada filter kategori
    if ($kategori !== "") {

        // kategori boleh banyak “Lunch,main,spiced”
        $filterKat = explode(",", $kategori);

        // cek apakah ada salah satu yang masuk array
        $match = false;
        foreach ($filterKat as $k) {
            if (in_array($k, $kategoriArr)) {
                $match = true;
                break;
            }
        }

        if (!$match) continue;
    }

    // juga cek search
    if ($search !== "" && stripos($row['nama_resep'], $search) === false) {
        continue;
    }

    $data[] = $row;
}

echo json_encode([
    "success" => true,
    "data" => $data
]);
