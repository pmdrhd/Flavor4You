<?php
header('Content-Type: application/json');
include '../koneksi.php';

$user_id   = $_POST['user_id']   ?? '';
$recipe_id = $_POST['recipe_id'] ?? '';

if ($user_id === '' || $recipe_id === '') {
    echo json_encode([
        "success" => false,
        "message" => "Data tidak lengkap"
    ]);
    exit;
}

$user_id   = intval($user_id);
$recipe_id = intval($recipe_id);

$sql = "DELETE FROM favorites 
        WHERE user_id = $user_id AND recipe_id = $recipe_id";

if ($conn->query($sql) === TRUE) {
    echo json_encode([
        "success" => true,
        "message" => "Berhasil menghapus dari favorit"
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Error: " . $conn->error
    ]);
}
?>
