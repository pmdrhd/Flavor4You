<?php
header('Content-Type: application/json');
include '../koneksi.php';

$user_id = $_GET['user_id'] ?? $_POST['user_id'] ?? '';

if ($user_id === '') {
    echo json_encode([
        "success" => false,
        "message" => "user_id wajib diisi"
    ]);
    exit;
}

$user_id = intval($user_id);

$sql = "SELECT r.id,
               r.nama_resep,
               r.gambar,
               r.bahan,
               r.instruksi,
               r.posted_by,
               f.created_at AS favorited_at
        FROM favorites f
        JOIN recipes r ON f.recipe_id = r.id
        WHERE f.user_id = $user_id
        ORDER BY f.created_at DESC";

$res = $conn->query($sql);

$data = [];
if ($res && $res->num_rows > 0) {
    while ($row = $res->fetch_assoc()) {
        $data[] = $row;
    }
}

echo json_encode([
    "success" => true,
    "data"    => $data
]);
?>
