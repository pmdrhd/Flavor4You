<?php
header('Content-Type: application/json');
include '../koneksi.php';

$user_id   = $_POST['user_id']   ?? '';
$recipe_id = $_POST['recipe_id'] ?? '';

if ($user_id === '' || $recipe_id === '') {
    echo json_encode([
        "success" => false,
        "message" => "Data tidak lengkap"
    ]);
    exit;
}

$user_id   = intval($user_id);
$recipe_id = intval($recipe_id);

// Cek apakah sudah ada di favorites
$sqlCheck = "SELECT id FROM favorites 
             WHERE user_id = $user_id AND recipe_id = $recipe_id
             LIMIT 1";
$resCheck = $conn->query($sqlCheck);

if ($resCheck && $resCheck->num_rows > 0) {
    echo json_encode([
        "success" => true,
        "message" => "Sudah ada di favorit"
    ]);
    exit;
}

$sqlInsert = "INSERT INTO favorites (user_id, recipe_id)
              VALUES ($user_id, $recipe_id)";

if ($conn->query($sqlInsert) === TRUE) {
    echo json_encode([
        "success" => true,
        "message" => "Berhasil menambahkan ke favorit",
        "favorite_id" => $conn->insert_id
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Error: " . $conn->error
    ]);
}
?>
